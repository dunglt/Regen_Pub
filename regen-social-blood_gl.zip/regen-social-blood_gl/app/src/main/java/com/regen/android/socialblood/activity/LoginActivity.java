package com.regen.android.socialblood.activity;

import android.net.Uri;
import android.support.v4.app.Fragment;

import com.regen.android.socialblood.fragment.LoginFragment;

/**
 * Created by vuduc on 1/18/16.
 */
public class LoginActivity extends BaseActivity implements LoginFragment.OnFragmentInteractionListener {
    @Override
    protected Fragment createFragment() {
        return LoginFragment.newInstance("Hello", "World");
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
