package com.regen.android.socialblood.activity;

import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.regen.android.socialblood.R;

/**
 * Created by vuduc on 1/18/16.
 */
public abstract class BaseActivity extends AppCompatActivity {
    protected FloatingActionButton mFab;
    protected Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutResId());
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        mFab = (FloatingActionButton) findViewById(R.id.fab);
        mFab.hide(); // Default hide it
        mFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        FragmentManager fm = getSupportFragmentManager();
        Fragment fragment = fm.findFragmentById(R.id.fragment_container);

        if (fragment == null) {
            fragment = createFragment();
            fm.beginTransaction()
                    .add(R.id.fragment_container, fragment)
                    .commit();
        }
    }

    @LayoutRes
    protected int getLayoutResId() {
        return R.layout.activity_base;
    }

    protected abstract Fragment createFragment();

    protected void setToolbarTitle(String title) {
        ActionBar bar = getSupportActionBar();
        if (bar != null) {
            bar.setTitle(title);
        }
    }

    protected void changeFragment(Fragment newFragment) {
        changeFragment(newFragment, 0, 0);
    }

    protected void changeFragment(Fragment newFragment, int animEnter, int animExit) {
        changeFragment(newFragment, animEnter, animExit, false);
    }

    protected void changeFragment(Fragment newFragment, int animEnter, int animExit, boolean addBackStack) {
        FragmentManager fm = getSupportFragmentManager();
        Fragment fragment = fm.findFragmentById(R.id.fragment_container);

        android.support.v4.app.FragmentTransaction ft = fm.beginTransaction();
        if (animEnter > 0 || animExit > 0) {
            ft.setCustomAnimations(animEnter, animExit);
        }

        if (addBackStack)
            ft.addToBackStack(null);

        if (fragment == null) {
            ft.add(R.id.fragment_container, newFragment);
        } else {
            ft.replace(R.id.fragment_container, newFragment);
        }
        ft.commit();
    }
}
